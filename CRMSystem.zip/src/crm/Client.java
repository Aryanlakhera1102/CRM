package crm;

public class Client {
    private String name;
    private String contact;
    private String requirement;

    public Client(String name, String contact, String requirement) {
        this.name = name;
        this.contact = contact;
        this.requirement = requirement;
    }

    public String getRequirement() {
        return requirement;
    }

    @Override
    public String toString() {
        return name + " (" + contact + ") - " + requirement;
    }
}