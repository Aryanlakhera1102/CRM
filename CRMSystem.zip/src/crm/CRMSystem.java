package crm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class CRMSystem extends JFrame {
    private DefaultListModel<Client> leadsModel = new DefaultListModel<>();
    private DefaultListModel<Client> hrModel = new DefaultListModel<>();
    private DefaultListModel<Client> designModel = new DefaultListModel<>();
    private DefaultListModel<Client> devModel = new DefaultListModel<>();

    private JList<Client> leadList, hrList, designList, devList;
    private JTextField nameField, contactField, requirementField;

    public CRMSystem() {
        setTitle("Digital CRM System");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JTabbedPane tabs = new JTabbedPane();

        // Lead Generation Panel
        JPanel leadPanel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        nameField = new JTextField();
        contactField = new JTextField();
        requirementField = new JTextField();
        JButton addLeadBtn = new JButton("Add Lead");

        inputPanel.add(new JLabel("Client Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Contact Info:"));
        inputPanel.add(contactField);
        inputPanel.add(new JLabel("Requirement:"));
        inputPanel.add(requirementField);
        inputPanel.add(new JLabel(""));
        inputPanel.add(addLeadBtn);

        leadList = new JList<>(leadsModel);
        leadPanel.add(inputPanel, BorderLayout.NORTH);
        leadPanel.add(new JScrollPane(leadList), BorderLayout.CENTER);

        JButton sendToHR = new JButton("Send to HR");
        leadPanel.add(sendToHR, BorderLayout.SOUTH);

        // HR Panel
        JPanel hrPanel = new JPanel(new BorderLayout());
        hrList = new JList<>(hrModel);
        JButton assignHR = new JButton("Assign to Team");
        hrPanel.add(new JScrollPane(hrList), BorderLayout.CENTER);
        hrPanel.add(assignHR, BorderLayout.SOUTH);

        // Design Panel
        JPanel designPanel = new JPanel(new BorderLayout());
        designList = new JList<>(designModel);
        JButton completeDesign = new JButton("Mark as Completed");
        designPanel.add(new JScrollPane(designList), BorderLayout.CENTER);
        designPanel.add(completeDesign, BorderLayout.SOUTH);

        // Development Panel
        JPanel devPanel = new JPanel(new BorderLayout());
        devList = new JList<>(devModel);
        JButton completeDev = new JButton("Mark as Completed");
        devPanel.add(new JScrollPane(devList), BorderLayout.CENTER);
        devPanel.add(completeDev, BorderLayout.SOUTH);

        tabs.add("Lead Generation", leadPanel);
        tabs.add("HR & Discussion", hrPanel);
        tabs.add("Design/Editing/Ads", designPanel);
        tabs.add("Development", devPanel);

        add(tabs);

        // Events
        addLeadBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String contact = contactField.getText().trim();
            String req = requirementField.getText().trim();
            if (!name.isEmpty() && !contact.isEmpty() && !req.isEmpty()) {
                leadsModel.addElement(new Client(name, contact, req));
                nameField.setText("");
                contactField.setText("");
                requirementField.setText("");
            }
        });

        sendToHR.addActionListener(e -> {
            Client selected = leadList.getSelectedValue();
            if (selected != null) {
                hrModel.addElement(selected);
                leadsModel.removeElement(selected);
            }
        });

        assignHR.addActionListener(e -> {
            Client selected = hrList.getSelectedValue();
            if (selected != null) {
                if (selected.getRequirement().toLowerCase().contains("design") ||
                    selected.getRequirement().toLowerCase().contains("ads")) {
                    designModel.addElement(selected);
                } else {
                    devModel.addElement(selected);
                }
                hrModel.removeElement(selected);
            }
        });

        completeDesign.addActionListener(e -> {
            Client selected = designList.getSelectedValue();
            if (selected != null) {
                designModel.removeElement(selected);
            }
        });

        completeDev.addActionListener(e -> {
            Client selected = devList.getSelectedValue();
            if (selected != null) {
                devModel.removeElement(selected);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CRMSystem().setVisible(true));
    }
}